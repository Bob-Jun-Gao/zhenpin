/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 44);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports) {

module.exports = "<header>    <div class=\"head clear\">        {{if !stuts}}        <div id=\"login\">            <i>&#xe646;</i>            <span>登录</span>        </div>        <div id=\"register\">            注册        </div>        {{else}}        <div id=\"user\">            <span>{{telephone}}</span>            <ul>                <li><a href=\"userhome.html\">账户中心</a></li>                <li><a>我的订单</a></li>                <li><a>我的收藏</a></li>                <li><a>地址管理</a></li>                <li><a class=\"launch\">退出登录</a></li>            </ul>        </div>        <div id=\"cart\">            <i>&#xe63f;</i>            <a href=\"shoppingcart.html\"><span>购物车</span></a>        </div>        {{/if}}    </div></header><nav>    <div class=\"nav\">        <div id=\"logo\">            <img src=\"./images/logo.png\" alt=\"\">        </div>        <div class=\"search\">            <input type=\"text\" placeholder=\"沙发\">            <i>&#xe651;</i>        </div>        <ul class=\"clear\">            <li  id=\"nav_index\" ><a href=\"index.html\">首页</a></li>            <li id=\"nav_furniture\"><a href=\"furniture.html\">家具</a></li>            <li id=\"nav_bed\"><a href=\"bed.html\">床品</a></li>            <li id=\"nav_decoration\"><a href=\"decoration.html\">家饰</a></li>            <li id=\"nav_fabric\"><a href=\"fabric.html\">布艺软装</a></li>            <li id=\"nav_shouna\"><a href=\"fabric.html\">收纳</a></li>            <li id=\"nav_new\"><a href=\"new_products.html\">新品</a></li>        </ul>    </div>    </nav>"

/***/ }),

/***/ 1:
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">    <div id=\"header\"></div>    <div id=\"container\"></div></div>"

/***/ }),

/***/ 2:
/***/ (function(module, exports) {

module.exports = "<footer>    甄选家居版权所有©2018</footer>"

/***/ }),

/***/ 3:
/***/ (function(module, exports) {

module.exports = "<div class=\"layer\">    <div class=\"lr\">        <div class=\"lr_logo\"><img src=\"./images/lr_logo.png\"/></div>        <div class=\"lr_close\"></div>        <div class=\"lr_title\">            <div class=\"lr_logbtn fl_l now\">                <button>登录</button>            </div>            <div class=\"lr_resbtn fl_r\">                <button>注册</button>            </div>        </div>        <div class=\"lr_login\">            <form >                <div>                    <input id=\"log_usn\" class=\"usn\" type=\"text\" name=\"usn\" placeholder=\"请输入手机号\"/>                </div>                <div>                    <input id=\"log_pwd\" class=\"pwd\" type=\"password\" name=\"pwd\" placeholder=\"请输入密码\"/>                </div>                <button class=\"login_btn\">登录</button>            </form>        </div>        <div class=\"lr_res\">            <form >                <!--method=\"post\" action=\"/api/user/register\"-->                <div>                    <input id=\"reg_usn\" class=\"usn\" type=\"text\" name=\"telephone\" placeholder=\"请输入手机号\"/>                </div>                <div>                    <input class=\"code\" type=\"text\" name=\"code\" placeholder=\"请输入验证码\" disabled/>                    <input class=\"code_btn\" type=\"button\"value=\"获取手机验证码\"/>                </div>                <div>                    <input id=\"reg_pwd\" class=\"pwd\" type=\"password\" name=\"password\" placeholder=\"请输入密码\"/>                </div>                <button class=\"res_btn\">注册</button>            </form>        </div>        <!--<div class=\"lr_register\">-->        <!--</div>-->    </div></div>"

/***/ }),

/***/ 4:
/***/ (function(module, exports) {

const loginAndResgister = {
    lr(data){
        // console.log(data)
        $("#login").on('click',()=>{
            console.log('1')
            $(".lr_logbtn button").addClass("lr_activ")
            $(".lr_resbtn button").removeClass("lr_activ")
            $(".layer").show();
            $(".lr_res").hide();
            $(".lr_login").show();
        })
        $("#register").on('click',()=>{
            $(".lr_resbtn button").addClass("lr_activ")
            $(".lr_logbtn button").removeClass("lr_activ")
            $(".layer").show();
            $(".lr_res").show();
            $(".lr_login").hide();
        })

        $(".lr_logbtn button").on('click',()=>{
            $(".lr_logbtn button").addClass("lr_activ")
            $(".lr_resbtn button").removeClass("lr_activ")
            $(".lr_login").show();
            $(".lr_res").hide();
        })
        $(".lr_resbtn button").on('click',()=>{
            $(".lr_resbtn button").addClass("lr_activ")
            $(".lr_logbtn button").removeClass("lr_activ")
            $(".lr_res").show();
            $(".lr_login").hide();
        })
        $(".lr_close").on('click',()=>{
            $(".layer").hide();
        })
    },

}

module.exports = loginAndResgister

/***/ }),

/***/ 44:
/***/ (function(module, exports, __webpack_require__) {

const indexTpl = __webpack_require__(1)
const headerTpl = __webpack_require__(0)
const footerTpl = __webpack_require__(2)
const logresTpl = __webpack_require__(3)
const logRes = __webpack_require__(4)
const userController = __webpack_require__(5)

const shoppingcartController = __webpack_require__(45)
const commonController = __webpack_require__(7)
// commonController.changeClass()

/*----------页面渲染----------*/
$("#root").html(indexTpl)

userController.usersAuthentication()

;(async () => {
    let html = await shoppingcartController.render()

    $("#container").html(html + footerTpl)


    //radio的选中和取消选中注意异步加载否则会在没有元素的时候执行没有效果
    ShoppingCart.shopRido();

    //添加修改数量以及删除商品
    ShoppingCart.shopAddSub();

})()
/*----------页面渲染结束----------*/


const ShoppingCart = {

    shopRido(){
        //radio的选中和取消选中注意异步加载否则会在没有元素的时候执行没有效果
        $('input:radio').click(function(){
            //alert(this.checked);
            var $radio = $(this);
            // if this was previously checked
            if ($radio.data('waschecked') == true){
                $radio.prop('checked', false);
                $radio.data('waschecked', false);
            } else {
                $radio.prop('checked', true);
                $radio.data('waschecked', true);
            }
        });
    },


    //添加修改数量以及删除商品
    shopAddSub() {
        $(".cart_jia").on("click",function(event){
            var shopNumEle = $(event.target).parents("tr").find(".shopNum");
            var saleEle = $(event.target).parents("tr").find(".td_price");
            var allSaleEle = $(event.target).parents("tr").find(".td_totalprice");
            console.log(allSaleEle)
            var shopnum = shopNumEle.val();
            // var id = shopNumEle.attr("data-id");
            shopNumEle.val(++shopnum);
            var allsale = saleEle.text()*shopnum;
            allSaleEle.text(allsale+".00");
            // this.setBagCookieNum(id,shopnum)
        }.bind(this));

        $(".cart_jian").on("click",function(){
            var shopNumEle = $(event.target).parents("tr").find(".shopNum");
            var saleEle = $(event.target).parents("tr").find(".td_price");
            var allSaleEle = $(event.target).parents("tr").find(".td_totalprice");
            var shopnum = shopNumEle.val();
            // var id = shopNumEle.attr("data-id");
            shopnum == 1 ? shopnum : --shopnum;
            shopNumEle.val(shopnum);
            var allsale = saleEle.text()*shopnum;
            allSaleEle.text(allsale+".00");
            // this.setBagCookieNum(id,shopnum)
        }.bind(this));

        $(".cp_del").on("click",function(event){
            var shopNumEle = $(event.target).parents("tr").find(".shopNum");
            // var id = shopNumEle.attr("data-id");
            // this.delBagCookieId(id);
        }.bind(this));

        $(".shopNum").on("change",function(event){
            var shopnum = $(event.target).val();
            var id = $(event.target).attr("data-id");
            var saleEle = $(event.target).parents("tr").find(".td_price");
            var allSaleEle = $(event.target).parents("tr").find(".td_totalprice");
            var allsale = saleEle.text()*shopnum;
            allSaleEle.text(allsale+".00");
            // this.setBagCookieNum(id,shopnum);
        }.bind(this))
    },


}

/***/ }),

/***/ 45:
/***/ (function(module, exports, __webpack_require__) {

// const userModel = require('../models/userMain.model')
const shoppingCartTpl = __webpack_require__(46)
const userController = {
    async render(){
        // let result = await userModel.find()
        // console.log(result);
        // let fresult = result.data.Category
        // console.log(fresult);
        // let html = template.render(userHomeTpl,fresult)
        let html = template.render(shoppingCartTpl)
        // console.log(html);
        return html
    },
}

module.exports = userController

/***/ }),

/***/ 46:
/***/ (function(module, exports) {

module.exports = "<div class=\"shoppingCart_main  clear\">    <div class=\"home_breadcrumbs\">        <ul class=\"clear\">            <li>首页</li>            <li>><a>账户中心</a></li>        </ul>    </div>    <div class=\"shoppingCart_container clear\">        <div class=\"shoppingCart_table\">            <table>                <colgroup>                    <col class=\"col_radio\">                    <col class=\"col_info\">                    <col class=\"col_price\">                    <col class=\"col_number\">                    <col class=\"col_totalprice\">                    <col class=\"col_dele\">                </colgroup>                <thead>                    <tr>                        <th><input type=\"radio\"/><label>全选</label></th>                        <th>商品信息</th>                        <th>单价</th>                        <th>数量</th>                        <th>小计</th>                        <th>操作</th>                    </tr>                </thead>                <tbody>                    <tr>                        <td>                            <div>                                <div class=\"fl_l\"><input type=\"radio\"/></div>                                <div class=\"fl_l shopping_img\"><img src=\"../images/1a030b6419099cdbb2e6283ead0f78b4.png\"/></div>                            </div>                        </td>                        <td>                            <div class=\"shopping_info\">                                <span>产品名</span>                                <p>这里是规格信息值保留一定的字段显示。。。</p>                            </div>                        </td>                        <td >￥<span class=\"td_price\">40</span></td>                        <td >                            <div>                                <a class=\"cart_jian\" href=\"javascript:void(0);\" ng-click=\"cal_minus()\">-</a>                                <input class=\"shopNum\" type=\"text\" value=\"1\"/>                                <a class=\"cart_jia\" href=\"javascript:void(0);\">+</a>                            </div>                        </td>                        <td >￥<span class=\"td_totalprice\">40</span></td>                        <td>删除</td>                    </tr>                    <tr>                        <td>                            <div>                                <div class=\"fl_l\"><input type=\"radio\"/></div>                                <div class=\"fl_l shopping_img\"><img src=\"../images/1a030b6419099cdbb2e6283ead0f78b4.png\"/></div>                            </div>                        </td>                        <td>                            <div class=\"shopping_info\">                                <span>产品名</span>                                <p>这里是规格信息值保留一定的字段显示。。。</p>                            </div>                        </td>                        <td >￥<span class=\"td_price\">40</span></td>                        <td >                            <div>                                <a class=\"cart_jian\" href=\"javascript:void(0);\" ng-click=\"cal_minus()\">-</a>                                <input class=\"shopNum\" type=\"text\" value=\"1\"/>                                <a class=\"cart_jia\" href=\"javascript:void(0);\">+</a>                            </div>                        </td>                        <td >￥<span class=\"td_totalprice\">40</span></td>                        <td>删除</td>                    </tr>                    <tr>                        <td>                            <div>                                <div class=\"fl_l\"><input type=\"radio\"/></div>                                <div class=\"fl_l shopping_img\"><img src=\"../images/1a030b6419099cdbb2e6283ead0f78b4.png\"/></div>                            </div>                        </td>                        <td>                            <div class=\"shopping_info\">                                <span>产品名</span>                                <p>这里是规格信息值保留一定的字段显示。。。</p>                            </div>                        </td>                        <td >￥<span class=\"td_price\">40</span></td>                        <td >                            <div>                                <a class=\"cart_jian\" href=\"javascript:void(0);\" ng-click=\"cal_minus()\">-</a>                                <input class=\"shopNum\" type=\"text\" value=\"1\"/>                                <a class=\"cart_jia\" href=\"javascript:void(0);\">+</a>                            </div>                        </td>                        <td >￥<span class=\"td_totalprice\">40</span></td>                        <td>删除</td>                    </tr>                </tbody>                <tfoot>                    <tr>                        <td>                            <div>                                <div class=\"fl_l\"><input class=\"totl\" type=\"radio\"/></div>                                已选<span class=\"class_num\">0</span>项                            </div>                        </td>                        <td>清空失效</td>                        <td>                            <div class=\"shopping_info\">                                <span>商品合计：<span>0</span></span>                                <span>邮费：<span>0</span></span>                            </div>                        </td>                        <td colspan=\"2\">                            总计：￥0                        </td>                        <td><buttom>结算</buttom></td>                    </tr>                </tfoot>            </table>        </div>    </div></div>"

/***/ }),

/***/ 5:
/***/ (function(module, exports, __webpack_require__) {


const headerTpl = __webpack_require__(0)
const userModel = __webpack_require__(6)

const wsCache = new WebStorageCache();

//用户登录注册token获取存储
const userLRController = {
    LogRes(){
        $('.res_btn').on('click',async() => {
            event.preventDefault()
            let {telephone, password} = {
                telephone: $('#reg_usn').val(),
                password: $('#reg_pwd').val()
            }
            let option = {
                telephone,
                password,
            }
            let result = await userModel.sign(option,'register')
            if(result.ret){
                alert('注册成功！切换到登录窗口。')
                // $(".lr").find('input').val('');
                // $('#')
            }else{
                alert(result.errmsg)
            }
        })

        $('.login_btn').on('click', async function(){
            event.preventDefault()
            let {telephone, password} = {
                telephone: $('#log_usn').val(),
                password: $('#log_pwd').val()
            }
            // console.log({telephone, password})
            let result = await userModel.sign({telephone, password},'login')
            //以下是测试用的
            let stuts = true
            wsCache.set('telephone', {telephone,stuts})
            location.reload()
            //以下是真正的登录逻辑，为了写其他页面，改成本地的虚假登录
            // if( result.ret == true){
            //     let stuts = true
            //     wsCache.set('telephone', {telephone,stuts})
            //     location.reload()
            // }
            
        }.bind(this))
    },

    //登录判定
    async usersAuthentication(){
        var storage = window.localStorage;
        if(storage.telephone){
            // console.log('storage',)
            var header = await template.render(headerTpl, wsCache.get('telephone'))
            $("#header").html(header)
            userLRController.userLaunch()
            // $('.launch').on('click', function(){
            //     console.log('123')
            //     wsCache.delete('telephone');
            //     window.location.replace("/index.html");
            //     // var header = template.render(headerTpl, {telephone: '', stuts:false})
            //     // $("#header").html(header)
            // })

        }else{
            // console.log('NOTstorage')
            var header = template.render(headerTpl, {telephone: '', stuts:false})
            $("#header").html(header)
        }


    },

    //----------头部渲染----------//
    renderHeader({telephone, stuts}) {
        // console.log('555')
        let header = template.render(headerTpl, {
            telephone,
            stuts
        })
        console.log(header)
        $("#header").html(header)
    },
    //----------退出登录----------//
    userLaunch(){
        $('.launch').on('click', function(){
            // console.log('123')
            wsCache.delete('telephone');
            location.replace('http://39.106.187.52:8080/ssh1fs/dev/index.html');
            // var header = template.render(headerTpl, {telephone: '', stuts:false})
            // $("#header").html(header)
        }.bind(this))
    }

}



module.exports = userLRController






/***/ }),

/***/ 6:
/***/ (function(module, exports) {

module.exports = {

    sign(data,url){
        // console.log(JSON.stringify(data))
        return $.ajax({
            url: '/qqq/api/user/' + url,

            contentType: "application/json",
            type: 'post',
            data: JSON.stringify(data),

            success: (result) => {
                return result
            }
        })
    }
}

/***/ }),

/***/ 7:
/***/ (function(module, exports) {

module.exports = {
    changeClass(){
        $('.nav ul li').on('click',function(){
            $(this).addClass('active').siblings().removeClass('active')
        })
    },
   changeNavClass(){
       let title = 'nav_' + $('main').attr('id')
        

   }
}

/***/ })

/******/ });