/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 32);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = "<header>    <div class=\"head clear\">        {{if !stuts}}        <div id=\"login\">            <i>&#xe646;</i>            <span>登录</span>        </div>        <div id=\"register\">            注册        </div>        {{else}}        <div id=\"user\">            <span>{{telephone}}</span>            <ul>                <li><a href=\"userhome.html\">账户中心</a></li>                <li><a>我的订单</a></li>                <li><a>我的收藏</a></li>                <li><a>地址管理</a></li>                <li><a class=\"launch\">退出登录</a></li>            </ul>        </div>        <div id=\"cart\">            <i>&#xe63f;</i>            <a href=\"shoppingcart.html\"><span>购物车</span></a>        </div>        {{/if}}    </div></header><nav>    <div class=\"nav\">        <div id=\"logo\">            <img src=\"./images/logo.png\" alt=\"\">        </div>        <div class=\"search\">            <input type=\"text\" placeholder=\"沙发\">            <i>&#xe651;</i>        </div>        <ul class=\"clear\">            <li  id=\"nav_index\" ><a href=\"index.html\">首页</a></li>            <li id=\"nav_furniture\"><a href=\"furniture.html\">家具</a></li>            <li id=\"nav_bed\"><a href=\"bed.html\">床品</a></li>            <li id=\"nav_decoration\"><a href=\"decoration.html\">家饰</a></li>            <li id=\"nav_fabric\"><a href=\"fabric.html\">布艺软装</a></li>            <li id=\"nav_shouna\"><a href=\"fabric.html\">收纳</a></li>            <li id=\"nav_new\"><a href=\"new_products.html\">新品</a></li>        </ul>    </div>    </nav>"

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">    <div id=\"header\"></div>    <div id=\"container\"></div></div>"

/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = "<footer>    甄选家居版权所有©2018</footer>"

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = "<div class=\"layer\">    <div class=\"lr\">        <div class=\"lr_logo\"><img src=\"./images/lr_logo.png\"/></div>        <div class=\"lr_close\"></div>        <div class=\"lr_title\">            <div class=\"lr_logbtn fl_l now\">                <button>登录</button>            </div>            <div class=\"lr_resbtn fl_r\">                <button>注册</button>            </div>        </div>        <div class=\"lr_login\">            <form >                <div>                    <input id=\"log_usn\" class=\"usn\" type=\"text\" name=\"usn\" placeholder=\"请输入手机号\"/>                </div>                <div>                    <input id=\"log_pwd\" class=\"pwd\" type=\"password\" name=\"pwd\" placeholder=\"请输入密码\"/>                </div>                <button class=\"login_btn\">登录</button>            </form>        </div>        <div class=\"lr_res\">            <form >                <!--method=\"post\" action=\"/api/user/register\"-->                <div>                    <input id=\"reg_usn\" class=\"usn\" type=\"text\" name=\"telephone\" placeholder=\"请输入手机号\"/>                </div>                <div>                    <input class=\"code\" type=\"text\" name=\"code\" placeholder=\"请输入验证码\" disabled/>                    <input class=\"code_btn\" type=\"button\"value=\"获取手机验证码\"/>                </div>                <div>                    <input id=\"reg_pwd\" class=\"pwd\" type=\"password\" name=\"password\" placeholder=\"请输入密码\"/>                </div>                <button class=\"res_btn\">注册</button>            </form>        </div>        <!--<div class=\"lr_register\">-->        <!--</div>-->    </div></div>"

/***/ }),
/* 4 */
/***/ (function(module, exports) {

const loginAndResgister = {
    lr(data){
        // console.log(data)
        $("#login").on('click',()=>{
            console.log('1')
            $(".lr_logbtn button").addClass("lr_activ")
            $(".lr_resbtn button").removeClass("lr_activ")
            $(".layer").show();
            $(".lr_res").hide();
            $(".lr_login").show();
        })
        $("#register").on('click',()=>{
            $(".lr_resbtn button").addClass("lr_activ")
            $(".lr_logbtn button").removeClass("lr_activ")
            $(".layer").show();
            $(".lr_res").show();
            $(".lr_login").hide();
        })

        $(".lr_logbtn button").on('click',()=>{
            $(".lr_logbtn button").addClass("lr_activ")
            $(".lr_resbtn button").removeClass("lr_activ")
            $(".lr_login").show();
            $(".lr_res").hide();
        })
        $(".lr_resbtn button").on('click',()=>{
            $(".lr_resbtn button").addClass("lr_activ")
            $(".lr_logbtn button").removeClass("lr_activ")
            $(".lr_res").show();
            $(".lr_login").hide();
        })
        $(".lr_close").on('click',()=>{
            $(".layer").hide();
        })
    },

}

module.exports = loginAndResgister

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {


const headerTpl = __webpack_require__(0)
const userModel = __webpack_require__(6)

const wsCache = new WebStorageCache();

//用户登录注册token获取存储
const userLRController = {
    LogRes(){
        $('.res_btn').on('click',async() => {
            event.preventDefault()
            let {telephone, password} = {
                telephone: $('#reg_usn').val(),
                password: $('#reg_pwd').val()
            }
            let option = {
                telephone,
                password,
            }
            let result = await userModel.sign(option,'register')
            if(result.ret){
                alert('注册成功！切换到登录窗口。')
                // $(".lr").find('input').val('');
                // $('#')
            }else{
                alert(result.errmsg)
            }
        })

        $('.login_btn').on('click', async function(){
            event.preventDefault()
            let {telephone, password} = {
                telephone: $('#log_usn').val(),
                password: $('#log_pwd').val()
            }
            // console.log({telephone, password})
            let result = await userModel.sign({telephone, password},'login')
            //以下是测试用的
            let stuts = true
            wsCache.set('telephone', {telephone,stuts})
            location.reload()
            //以下是真正的登录逻辑，为了写其他页面，改成本地的虚假登录
            // if( result.ret == true){
            //     let stuts = true
            //     wsCache.set('telephone', {telephone,stuts})
            //     location.reload()
            // }
            
        }.bind(this))
    },

    //登录判定
    async usersAuthentication(){
        var storage = window.localStorage;
        if(storage.telephone){
            // console.log('storage',)
            var header = await template.render(headerTpl, wsCache.get('telephone'))
            $("#header").html(header)
            userLRController.userLaunch()
            // $('.launch').on('click', function(){
            //     console.log('123')
            //     wsCache.delete('telephone');
            //     window.location.replace("/index.html");
            //     // var header = template.render(headerTpl, {telephone: '', stuts:false})
            //     // $("#header").html(header)
            // })

        }else{
            // console.log('NOTstorage')
            var header = template.render(headerTpl, {telephone: '', stuts:false})
            $("#header").html(header)
        }


    },

    //----------头部渲染----------//
    renderHeader({telephone, stuts}) {
        // console.log('555')
        let header = template.render(headerTpl, {
            telephone,
            stuts
        })
        console.log(header)
        $("#header").html(header)
    },
    //----------退出登录----------//
    userLaunch(){
        $('.launch').on('click', function(){
            // console.log('123')
            wsCache.delete('telephone');
            location.replace('http://39.106.187.52:8080/ssh1fs/dev/index.html');
            // var header = template.render(headerTpl, {telephone: '', stuts:false})
            // $("#header").html(header)
        }.bind(this))
    }

}



module.exports = userLRController






/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports = {

    sign(data,url){
        // console.log(JSON.stringify(data))
        return $.ajax({
            url: '/qqq/api/user/' + url,

            contentType: "application/json",
            type: 'post',
            data: JSON.stringify(data),

            success: (result) => {
                return result
            }
        })
    }
}

/***/ }),
/* 7 */
/***/ (function(module, exports) {

module.exports = {
    changeClass(){
        $('.nav ul li').on('click',function(){
            $(this).addClass('active').siblings().removeClass('active')
        })
    },
   changeNavClass(){
       let title = 'nav_' + $('main').attr('id')
        

   }
}

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

const userhomeModel = __webpack_require__(33)
const userHomeTpl = __webpack_require__(34)
//账户中心
const centerTpl = __webpack_require__(35)

//我的订单
const ordersTpl = __webpack_require__(36)

//收藏页面渲染+数据模版
const colTpl = __webpack_require__(37)
const collectionTpl = __webpack_require__(38)

// 我的足迹
const historyTpl = __webpack_require__(39)
//地址管理
const addressTpl = __webpack_require__(40)
// 账号安全
const safetyTpl = __webpack_require__(41)

const userController = {
    async render() {
        let html = template.render(userHomeTpl)
        return html
    },
    changepic() {
        let user_avatarfile = $('.user_avatarfile')
        user_avatarfile.on('change', function () {
            let img = user_avatarfile.val()
            // $('.user_avatar img').attr('src', img)

            let file = user_avatarfile[0].files[0];
            if (typeof FileReader === 'undefined') {
                alert('buzhichi')
            }
            if (window.FileReader) {
                var reader = new FileReader()
                reader.readAsDataURL(file)
                console.log(file)
                console.log(reader)
                console.log(reader.result)
                reader.onload = function (e) {
                    alert('文件读取完成');
                    imgFile = e.target.result;
                    console.log(imgFile);
                    $(".user_avatar img").attr('src', imgFile);
                };
            }
        })
    },
    homeRender({res,req,nect}){
        res.render(centerTpl) 
    },
    addressRender({res,req,nect}){
        res.render(addressTpl) 
    },
    //我的收藏
    async collectionsRender({res,req,nect}){
        let result = await userController._colData()
        res.render(collectionTpl) 
        let div = document.getElementById('collection_box')
        div.innerHTML = result
    },
    async _colData(){
        let result = await userhomeModel.find()
        let final = result.data.Category
        console.log(final);
        let html = template.render(colTpl,final)
        // console.log(html);
        return html
    },
    //我的订单
    ordersRender({res,req,nect}){
        res.render(ordersTpl) 
        userController.ordersBtn()

    },
    ordersBtn(){
        $('#dispatched').show();
        $('.user_base').find('span').on('click',function(){
            // $('#dispatched').show().siblings().hide();
            // console.log(1);
            $(this).siblings().removeClass('active').end().show();
            let box ='#'+$(this).context.id.slice(4)
            $(box).siblings().hide().end().show();
        })
    },
    // 我的足迹
    async myHisttoryRender({res,req,nect}){
        let result = await userController._colData()
        res.render(historyTpl) 
        let div = document.getElementById('collection_box')
        div.innerHTML = result
    },
    // 账号安全
    safetyRender({res,req,nect}){
        res.render(safetyTpl)
    },
}

module.exports = userController

/***/ }),
/* 9 */,
/* 10 */,
/* 11 */,
/* 12 */,
/* 13 */,
/* 14 */,
/* 15 */,
/* 16 */,
/* 17 */,
/* 18 */,
/* 19 */,
/* 20 */,
/* 21 */,
/* 22 */,
/* 23 */,
/* 24 */,
/* 25 */,
/* 26 */,
/* 27 */,
/* 28 */,
/* 29 */,
/* 30 */,
/* 31 */,
/* 32 */
/***/ (function(module, exports, __webpack_require__) {


const indexTpl = __webpack_require__(1)
const headerTpl = __webpack_require__(0)
const footerTpl = __webpack_require__(2)
const logresTpl = __webpack_require__(3)
const logRes = __webpack_require__(4)
const userController = __webpack_require__(5)

const userhomeController = __webpack_require__(8)
const commonController = __webpack_require__(7)
// commonController.changeClass()
$("#root").html(indexTpl)
;(async () => {
    let html = await userhomeController.render()
    $("#container").html(html + footerTpl)
    userController.usersAuthentication()
    userhomeController.changepic()
    //这个引入不放在这就报错！
    __webpack_require__(42)   
    //地址管理页面的右侧选项卡
    $('#router-view').on('click','#add_manage a',() => {
        $('#new_address').hide();
        $('#address_manage').show();
        $('#add_manage').removeClass('active').addClass('active').siblings().removeClass('active')
    })
    $('#router-view').on('click','#add_new a',() => {
        $('#address_manage').hide();
        $('#new_address').show();
        console.log($(this));
        $('#add_new').addClass('active').siblings().removeClass('active')
    })
    // userhomeController.ordersBtn()
    
})()





/***/ }),
/* 33 */
/***/ (function(module, exports) {

module.exports = {
    find(){
        return fetch('http://39.106.187.52:8080/ssh1fs/mock/collections.json')
        .then(response => response.json())
        .then(result => {
            return result
        })
    }
}

/***/ }),
/* 34 */
/***/ (function(module, exports) {

module.exports = "<div class=\"userhome_main  clear\">    <div class=\"home_breadcrumbs\">        <ul class=\"clear\">            <li>首页</li>            <li>>                <a>账户中心</a>            </li>        </ul>    </div>    <div class=\"userhome_container clear\">        <div class=\"userhome_side fl_l\">            <div class=\"userhome_side_head\">                <div class=\"user_img\"></div>                <div class=\"user_name\">用户昵称</div>            </div>            <div class=\"user_side_nav\">                <ul class=\"clear\">                    <li class=\"user_active\">                        <a href=\"#/home\">账户中心</a>                    </li>                    <li>                        <a href=\"#/safety\">账户安全</a>                    </li>                    <li>                        <a href=\"#/myHisttory\">我的足迹</a>                    </li>                    <li>                        <a href=\"#/orders\">我的订单</a>                    </li>                    <li>                        <a href=\"#/collections\">我的收藏</a>                    </li>                    <li>                        <a href=\"#/address\">地址管理</a>                    </li>                </ul>            </div>        </div>        <div class=\"userhome_content fl_r\">            <div id=\"router-view\">                            </div>        </div>    </div></div>"

/***/ }),
/* 35 */
/***/ (function(module, exports) {

module.exports = "<div class=\"user_base\">    <span>基本资料</span></div><div>    <form class=\"userhome_form\">        <div class=\"form_group clear\">            <label class=\"avatar fl_l\">用户头像</label>            <div class=\"fl_l\">                <input class=\"user_avatarfile\" name=\"user_img\" type=\"file\" />                <div class=\"user_avatar\">                    <img src=\"./images/img_bg.png\" />                </div>            </div>        </div>        <div class=\"form_group clear\">            <label class=\"fl_l\">用户ID</label>            <div class=\"fl_l\">                <input type=\"text\" value=\"12345\" disabled=\"disabled\" />            </div>        </div>        <div class=\"form_group clear\">            <label class=\"fl_l letter\">账号</label>            <div class=\"fl_l\">                <input type=\"text\" value=\"15094952948\" disabled=\"disabled\" />            </div>        </div>        <div class=\"form_group clear\">            <label class=\"fl_l letter\">昵称</label>            <div class=\"fl_l\">                <input type=\"text\" class=\"othername\" placeholder=\"请输入昵称\" />            </div>        </div>        <div class=\"form_group clear\">            <label class=\"fl_l letter\">性别</label>            <div class=\"fl_l\">                <input class=\"user_sex fl_l\" name=\"sex\" type=\"radio\" value=\'male\' checked />                <label class=\"fl_l\">先生</label>                <input class=\"user_sex fl_l\" name=\"sex\" type=\"radio\" value=\"female\" />                <label class=\"fl_l\">女士</label>            </div>        </div>        <div class=\"form_group clear\">            <label class=\"fl_l\">手机号码</label>            <div class=\"fl_l\">                <input name=\"phone\" type=\"text\" placeholder=\"15094952948\" />            </div>        </div>        <div class=\"form_group clear\">            <input class=\"sumbit_userhome\" type=\"button\" value=\"保存\" />        </div>    </form></div>"

/***/ }),
/* 36 */
/***/ (function(module, exports) {

module.exports = "<div class=\"user_base clear\">    <span id=\"btn_dispatched\" class=\"active\">        <a>待收货（            <b>2</b>            ）</a>    </span>    <span id=\"btn_obligation\">        <a>待付款（            <b>2</b>            ）</a>    </span>    <span id=\"btn_received\">        <a>已收货（            <b>2</b>            ）</a>    </span>    <span id=\"btn_refunds\">        <a>退款订单（            <b>2</b>            ）</a>    </span>    <span id=\"btn_allOrders\">        <a>全部订单（            <b>8</b>            ）</a>    </span></div><div id=\"orders\">    <!-- 空订单 -->    <div id=\"empty\">        <img src=\"./images/empty.png\" alt=\"\">        <p>没有相应订单数据</p>    </div>    <!-- 待收货 -->    <div id=\"dispatched\">        <ul>            <li class=\"clear\">                <p>订单日期：2018/06/07 20:49:20</p>                <span class=\"order_state\">待收货</span>                <div class=\"order_info\">                    <img src=\"./images/6b188267736db8ef2422e44db27eb259.png\" alt=\"\">                    <p>                        <span>产品名</span>                        <span>规格</span>                    </p>                    <b>¥40.00</b>                    <i>x1</i>                    <div>运费 ：￥0.00元</div>                </div>                <div class=\"operations\">                    <p>共一件商品, 订单总金额为: 40元</p>                    <button class=\"LookAtLogistics\">查看物流</button>                    <button class=\"confirm\">确认收货</button>                </div>            </li>            <li class=\"clear\">                <p>订单日期：2018/06/07 20:49:20</p>                <span class=\"order_state\">待收货</span>                <div class=\"order_info\">                    <img src=\"./images/6b188267736db8ef2422e44db27eb259.png\" alt=\"\">                    <p>                        <span>产品名</span>                        <span>规格</span>                    </p>                    <b>¥40.00</b>                    <i>x1</i>                    <div>运费 ：￥0.00元</div>                </div>                <div class=\"operations\">                    <p>共一件商品, 订单总金额为: 40元</p>                    <button class=\"LookAtLogistics\">查看物流</button>                    <button class=\"confirm\">确认收货</button>                </div>            </li>        </ul>    </div>    <!-- 待付款 -->    <div id=\"obligation\">        <ul>            <li class=\"clear\">                <p>订单日期：2018/06/07 20:49:20</p>                <b class=\"tips\">1小时后订单关闭</b>                <span class=\"order_state\">待付款</span>                <div class=\"order_info\">                    <img src=\"./images/7880da24e96f6e18916b16d0f1482369.png\" alt=\"\">                    <p>                        <span>产品名</span>                        <span>规格</span>                    </p>                    <b>¥40.00</b>                    <i>x1</i>                    <div>运费 ：￥0.00元</div>                </div>                <div class=\"operations\">                    <p>共一件商品, 订单总金额为: 40元</p>                    <button class=\"LookAtLogistics\">取消订单</button>                    <button class=\"confirm\">去付款</button>                </div>            </li>            <li class=\"clear\">                <p>订单日期：2018/06/07 20:49:20</p>                <b class=\"tips\">1小时后订单关闭</b>                <span class=\"order_state\">待付款</span>                <div class=\"order_info\">                    <img src=\"./images/7880da24e96f6e18916b16d0f1482369.png\" alt=\"\">                    <p>                        <span>产品名</span>                        <span>规格</span>                    </p>                    <b>¥40.00</b>                    <i>x1</i>                    <div>运费 ：￥0.00元</div>                </div>                <div class=\"operations\">                    <p>共一件商品, 订单总金额为: 40元</p>                    <button class=\"LookAtLogistics\">取消订单</button>                    <button class=\"confirm\">去付款</button>                </div>            </li>        </ul>    </div>    <!-- 已收货 -->    <div id=\"received\">        <ul>            <li class=\"clear\">                <p>订单日期：2018/06/07 20:49:20</p>                <span class=\"order_state\">已收货</span>                <div class=\"order_info\">                    <img src=\"./images/dd192cb3cc17292ebfed62c5b6a975e7.png\" alt=\"\">                    <p>                        <span>产品名</span>                        <span>规格</span>                    </p>                    <b>¥40.00</b>                    <i>x1</i>                    <div>运费 ：￥0.00元</div>                </div>                <div class=\"operations\">                    <p>共一件商品, 订单总金额为: 40元</p>                    <button class=\"LookAtLogistics\">申请售后</button>                    <button class=\"confirm\">去评价</button>                </div>            </li>            <li class=\"clear\">                <p>订单日期：2018/06/07 20:49:20</p>                <span class=\"order_state\">已收货</span>                <div class=\"order_info\">                    <img src=\"./images/dd192cb3cc17292ebfed62c5b6a975e7.png\" alt=\"\">                    <p>                        <span>产品名</span>                        <span>规格</span>                    </p>                    <b>¥40.00</b>                    <i>x1</i>                    <div>运费 ：￥0.00元</div>                </div>                <div class=\"operations\">                    <p>共一件商品, 订单总金额为: 40元</p>                    <button class=\"LookAtLogistics\">申请售后</button>                    <button class=\"confirm\">去评价</button>                </div>            </li>        </ul>    </div>    <!-- 退款订单 -->    <div id=\"refunds\">        <ul>            <li class=\"clear\">                <p>订单日期：2018/06/07 20:49:20</p>                <span class=\"order_state\">退款中</span>                <div class=\"order_info\">                    <img src=\"./images/437a7645eeb159f20a5cc4ed8d566abe.png\" alt=\"\">                    <p>                        <span>产品名</span>                        <span>规格</span>                    </p>                    <b>¥40.00</b>                    <i>x1</i>                    <div>运费 ：￥0.00元</div>                </div>                <div class=\"operations\">                    <p>共一件商品, 订单总金额为: 40元</p>                    <button class=\"LookAtLogistics\">取消退款</button>                    <button class=\"confirm\">修改申请</button>                </div>            </li>            <li class=\"clear\">                <p>订单日期：2018/06/07 20:49:20</p>                <span class=\"order_state\">已退款</span>                <div class=\"order_info\">                    <img src=\"./images/437a7645eeb159f20a5cc4ed8d566abe.png\" alt=\"\">                    <p>                        <span>产品名</span>                        <span>规格</span>                    </p>                    <b>¥40.00</b>                    <i>x1</i>                    <div>运费 ：￥0.00元</div>                </div>                <div class=\"operations\">                    <p>共一件商品, 订单总金额为: 40元</p>                    <button class=\"LookAtLogistics\">删除订单</button>                    <button class=\"confirm\">退款成功</button>                </div>            </li>        </ul>    </div>    <div id=\"allOrders\">        <ul>            <li class=\"clear\">                <p>订单日期：2018/06/07 20:49:20</p>                <span class=\"order_state\">退款中</span>                <div class=\"order_info\">                    <img src=\"./images/43cf6a4e39980877d06921849e1b7b82.png\" alt=\"\">                    <p>                        <span>产品名</span>                        <span>规格</span>                    </p>                    <b>¥40.00</b>                    <i>x1</i>                    <div>运费 ：￥0.00元</div>                </div>                <div class=\"operations\">                    <p>共一件商品, 订单总金额为: 40元</p>                    <button class=\"LookAtLogistics\">取消退款</button>                    <button class=\"confirm\">修改申请</button>                </div>            </li>            <li class=\"clear\">                <p>订单日期：2018/06/07 20:49:20</p>                <span class=\"order_state\">已退款</span>                <div class=\"order_info\">                    <img src=\"./images/43cf6a4e39980877d06921849e1b7b82.png\" alt=\"\">                    <p>                        <span>产品名</span>                        <span>规格</span>                    </p>                    <b>¥40.00</b>                    <i>x1</i>                    <div>运费 ：￥0.00元</div>                </div>                <div class=\"operations\">                    <p>共一件商品, 订单总金额为: 40元</p>                    <button class=\"LookAtLogistics\">删除订单</button>                    <button class=\"confirm\">退款成功</button>                </div>            </li>            <li class=\"clear\">                <p>订单日期：2018/06/07 20:49:20</p>                <b class=\"tips\">1小时后订单关闭</b>                <span class=\"order_state\">待付款</span>                <div class=\"order_info\">                    <img src=\"./images/43cf6a4e39980877d06921849e1b7b82.png\" alt=\"\">                    <p>                        <span>产品名</span>                        <span>规格</span>                    </p>                    <b>¥40.00</b>                    <i>x1</i>                    <div>运费 ：￥0.00元</div>                </div>                <div class=\"operations\">                    <p>共一件商品, 订单总金额为: 40元</p>                    <button class=\"LookAtLogistics\">取消订单</button>                    <button class=\"confirm\">去付款</button>                </div>            </li>            <li class=\"clear\">                <p>订单日期：2018/06/07 20:49:20</p>                <span class=\"order_state\">待收货</span>                <div class=\"order_info\">                    <img src=\"./images/43cf6a4e39980877d06921849e1b7b82.png\" alt=\"\">                    <p>                        <span>产品名</span>                        <span>规格</span>                    </p>                    <b>¥40.00</b>                    <i>x1</i>                    <div>运费 ：￥0.00元</div>                </div>                <div class=\"operations\">                    <p>共一件商品, 订单总金额为: 40元</p>                    <button class=\"LookAtLogistics\">查看物流</button>                    <button class=\"confirm\">确认收货</button>                </div>            </li>            <li class=\"clear\">                <p>订单日期：2018/06/07 20:49:20</p>                <span class=\"order_state\">待收货</span>                <div class=\"order_info\">                    <img src=\"./images/43cf6a4e39980877d06921849e1b7b82.png\" alt=\"\">                    <p>                        <span>产品名</span>                        <span>规格</span>                    </p>                    <b>¥40.00</b>                    <i>x1</i>                    <div>运费 ：￥0.00元</div>                </div>                <div class=\"operations\">                    <p>共一件商品, 订单总金额为: 40元</p>                    <button class=\"LookAtLogistics\">查看物流</button>                    <button class=\"confirm\">确认收货</button>                </div>            </li>            <li class=\"clear\">                <p>订单日期：2018/06/07 20:49:20</p>                <b class=\"tips\">1小时后订单关闭</b>                <span class=\"order_state\">待付款</span>                <div class=\"order_info\">                    <img src=\"./images/43cf6a4e39980877d06921849e1b7b82.png\" alt=\"\">                    <p>                        <span>产品名</span>                        <span>规格</span>                    </p>                    <b>¥40.00</b>                    <i>x1</i>                    <div>运费 ：￥0.00元</div>                </div>                <div class=\"operations\">                    <p>共一件商品, 订单总金额为: 40元</p>                    <button class=\"LookAtLogistics\">取消订单</button>                    <button class=\"confirm\">去付款</button>                </div>            </li>            <li class=\"clear\">                <p>订单日期：2018/06/07 20:49:20</p>                <b class=\"tips\">1小时后订单关闭</b>                <span class=\"order_state\">待付款</span>                <div class=\"order_info\">                    <img src=\"./images/43cf6a4e39980877d06921849e1b7b82.png\" alt=\"\">                    <p>                        <span>产品名</span>                        <span>规格</span>                    </p>                    <b>¥40.00</b>                    <i>x1</i>                    <div>运费 ：￥0.00元</div>                </div>                <div class=\"operations\">                    <p>共一件商品, 订单总金额为: 40元</p>                    <button class=\"LookAtLogistics\">取消订单</button>                    <button class=\"confirm\">去付款</button>                </div>            </li>        </ul>    </div></div>"

/***/ }),
/* 37 */
/***/ (function(module, exports) {

module.exports = "<ul>    {{each productList}}    <li pid=\"{{$value.pid}}\">        <a href=\"###\">            <img src=\"{{$value.imgUrl}}\" alt=\"\">        </a>        <p>{{$value.productName}}</p>        <b>¥            <span>{{$value.marketPrice}}</span>        </b>        <i></i>        <h6>{{$value.productInfo}}</h6>    </li>    {{/each}}</ul>"

/***/ }),
/* 38 */
/***/ (function(module, exports) {

module.exports = "<div class=\"user_base clear\">    <span id=\"myCollection\" class=\"active\">        <a>我的收藏</a>    </span>    <b id=\"deleteAll\">批量删除</b></div><div id=\"myCollections\">    <div class=\"date\">2018.06.01</div>    <span class=\"line\"></span>    <div id=\"collection_box\">            </div></div>"

/***/ }),
/* 39 */
/***/ (function(module, exports) {

module.exports = "<div class=\"user_base clear\">        <span id=\"myCollection\" class=\"active\">            <a>我的足迹</a>        </span>        <b id=\"deleteAll\">批量删除</b>    </div>    <div id=\"myCollections\">        <div class=\"date\">2018.06.04</div>        <span class=\"line\"></span>        <div id=\"collection_box\">                    </div>    </div>"

/***/ }),
/* 40 */
/***/ (function(module, exports) {

module.exports = "<div class=\"user_base\">    <span id=\"add_manage\" class=\"active\">        <a>地址管理</a>    </span>    <span id=\"add_new\">        <a>新建地址</a>    </span></div><div id=\"address_manage\">    <div class=\"address_nav\">        <ul class=\"clear\">            <li>默认地址</li>            <li>收货人</li>            <li>地址</li>            <li>联系方式</li>            <li>操作</li>        </ul>    </div>    <form class=\"address_form\">        <ul class=\"address_item clear\">            <li class=\"default_address\">                <input type=\"radio\" name=\"address\" checked>            </li>            <li class=\"master\">宋三杯水</li>            <li class=\"address_detail\">吉林省长春市绿园区</li>            <li class=\"contact\">234****1234</li>            <li class=\"operate\">                <span id=\"edit\">修改</span>                <span id=\"delete\">删除</span>            </li>        </ul>        <ul class=\"address_item clear\">            <li class=\"default_address\">                <input type=\"radio\" name=\"address\">            </li>            <li class=\"master\">宋三杯水</li>            <li class=\"address_detail\">吉林省长春市绿园区</li>            <li class=\"contact\">234****1234</li>            <li class=\"operate\">                <span id=\"edit\">修改</span>                <span id=\"delete\">删除</span>            </li>        </ul>        <ul class=\"address_item clear\">            <li class=\"default_address\">                <input type=\"radio\" name=\"address\">            </li>            <li class=\"master\">宋三杯水</li>            <li class=\"address_detail\">吉林省长春市绿园区</li>            <li class=\"contact\">234****1234</li>            <li class=\"operate\">                <span id=\"edit\">修改</span>                <span id=\"delete\">删除</span>            </li>        </ul>    </form></div><div id=\"new_address\">    <form action=\"###\">        <div class=\"position\">            所在地区：            <select name=\"province\" id=\"province\">                <option value=\"\">请选择</option>                <option value=\"北京市\">北京市</option>                <option value=\"天津市\">天津市</option>                <option value=\"重庆市\">重庆市</option>                <option value=\"上海市\">上海市</option>                <option value=\"上海市\">吉林省</option>            </select>            <select name=\"city\" id=\"city\">                <option value=\"\">请选择</option>                <option value=\"长春市\">长春市</option>                <option value=\"吉林市\">吉林市</option>                <option value=\"四平市\">四平市</option>            </select>            <select name=\"zone\" id=\"zone\">                <option value=\"\">请选择</option>                <option value=\"朝阳区\">朝阳区</option>                <option value=\"绿园区\">绿园区</option>                <option value=\"宽城区\">宽城区</option>            </select>        </div>        <div class=\"address_detail\">            <span>详细地址：</span>            <textarea name=\"address_detail\" id=\"address_detail\" cols=\"90\" rows=\"4\"></textarea>        </div>        <div class=\"host\">            收货人：            <input type=\"text\" id=\"guest\">手机号码：            <input type=\"text\" name=\"telephone\" id=\"telephone\">        </div>        <div class=\"makeitdefault\">            <input type=\"checkbox\" name=\"makeitdefault\" id=\"makeitdefault\">设为默认            <button id=\"btn_save\">保存地址</button>            <button id=\"btn_cancle\">取消</button>        </div>    </form></div>"

/***/ }),
/* 41 */
/***/ (function(module, exports) {

module.exports = "<div class=\"user_base clear\">    <span id=\"btn_safety\" class=\"active\">        <a>账号安全</a>    </span></div><div id=\"safety\">    <p>当前帐号<span>15012341234</span><b>更换号码</b></p>    <p>绑定手机<span>绑定手机：150****2948，若手机丢失或停用，请及时更换</span><b>立即设置</b></p>    <p>支付密码<span>支付密码启用后，将作为您帐号资产使用时的身份证明</span><b>更换密码</b></p></div>"

/***/ }),
/* 42 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_sme_router__ = __webpack_require__(43);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_sme_router___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_sme_router__);

const userhomeController = __webpack_require__(8)

const router = new __WEBPACK_IMPORTED_MODULE_0_sme_router___default.a('router-view')

// // route config
router.route('/home', (req, res, next) => {
    userhomeController.homeRender({req, res, next, router})
})
router.route('/safety', (req, res, next) => {
    userhomeController.safetyRender({req, res, next, router})
})
router.route('/myHisttory', (req, res, next) => {
    userhomeController.myHisttoryRender({req, res, next, router})
})
router.route('/orders', (req, res, next) => {
    userhomeController.ordersRender({req, res, next, router})
})
router.route('/collections', (req, res, next) => {
    userhomeController.collectionsRender({req, res, next, router})
})
router.route('/address', (req, res, next) => {
    userhomeController.addressRender({req, res, next, router})
})
router.route('*', (req, res, next) => {
  res.redirect('/home')
})


/***/ }),
/* 43 */
/***/ (function(module, exports, __webpack_require__) {

!function(e,t){ true?module.exports=t():"function"==typeof define&&define.amd?define([],t):"object"==typeof exports?exports["sme-router"]=t():e["sme-router"]=t()}(this,function(){return function(e){function t(r){if(n[r])return n[r].exports;var o=n[r]={i:r,l:!1,exports:{}};return e[r].call(o.exports,o,o.exports,t),o.l=!0,o.exports}var n={};return t.m=e,t.c=n,t.d=function(e,n,r){t.o(e,n)||Object.defineProperty(e,n,{configurable:!1,enumerable:!0,get:r})},t.n=function(e){var n=e&&e.__esModule?function(){return e.default}:function(){return e};return t.d(n,"a",n),n},t.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},t.p="",t(t.s=1)}([function(e,t,n){"use strict";function r(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}Object.defineProperty(t,"__esModule",{value:!0});var o=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),i=n(6),a=n(7),u=function(){function e(t){r(this,e),this.matcher=t.matcher,this._matchedCount=0}return o(e,[{key:"_fireHandlers",value:function(e,t){for(var n=0;n<e.length;n++){var r=e[n],o=this._getCache(r),i={body:t||o,query:r.query,params:r.params};(0,a.def)(i,"route",r.path),(0,a.def)(i,"url",r.url),!t&&o&&(i._id=r._id),r.handler(i),this._cacheBody(t,r)}}},{key:"_getCache",value:function(e){return(0,i.getCache)(e._id)}},{key:"_cacheBody",value:function(e,t){e&&(0,i.setCache)(t._id,e)}},{key:"getMatchedCount",value:function(){return this._matchedCount}},{key:"go",value:function(e,t){}},{key:"redirect",value:function(e,t){}},{key:"back",value:function(){}},{key:"stop",value:function(){}}]),e}();t.default=u},function(e,t,n){"use strict";function r(e){return e&&e.__esModule?e:{default:e}}function o(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}Object.defineProperty(t,"__esModule",{value:!0});var i=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),a=n(2),u=r(a),s=n(5),c=r(s),l=n(8),f=r(l),h=function(){function e(t){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"hash";if(o(this,e),this._mount=document.getElementById(t),!this._mount)throw new Error("Can not get mount point document.getElementById(#"+t+")...");this._subRouteView='<div id="__sub-route-view"></div>',this._subMount=null,this._isPassing=!1,this._cache={},this._middlewares=[],this._matcher=new u.default,this._history="hash"===n?new f.default({matcher:this._matcher}):new c.default({matcher:this._matcher})}return i(e,[{key:"render",value:function(e){this._isPassing?this._subMount.innerHTML=e:this._mount.innerHTML=e}},{key:"next",value:function(e){this._mount.innerHTML=e,this._isPassing=this._history.getMatchedCount()>1,this._subMount=document.querySelector("#__sub-route-view")}},{key:"subRoute",value:function(){return this._subRouteView}},{key:"use",value:function(e){this._middlewares.push(e)}},{key:"route",value:function(e,t){var n=this;this._matcher.add(e,function(r){if("*"!==e&&!r._id)for(var o=0;o<n._middlewares.length;o++)n._middlewares[o](r);t(r,n,n.next.bind(n))})}},{key:"go",value:function(e,t){this._isPassing=!1,this._history.go(e,t)}},{key:"redirect",value:function(e,t){this._isPassing=!1,this._history.redirect(e,t)}},{key:"back",value:function(){this._isPassing=!1,this._history.back()}},{key:"stop",value:function(){this._history.stop()}}]),e}();t.default=h},function(e,t,n){"use strict";function r(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}Object.defineProperty(t,"__esModule",{value:!0});var o=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),i=n(3),a=function(e){return e&&e.__esModule?e:{default:e}}(i),u=n(4),s=function(){function e(){r(this,e),this._routes=[],this._id=0}return o(e,[{key:"match",value:function(e){var t=[],n="",r=e.indexOf("?"),o=!0;r>-1&&(n=e.substr(r),e=e.slice(0,r));for(var i=0;i<this._routes.length;i++){var a=this._routes[i],s=a.reg.exec(e);if(s){if("*"!==a.path&&(o=!1),!o&&"*"===a.path)continue;t.push({_id:a._id,path:a.path,url:e+n,params:this._getParams(a.params,s),query:(0,u.parseQuery)(n),handler:a.handler})}}return t}},{key:"add",value:function(e,t){var n=this._toReg({path:e,handler:t});n._id=++this._id,this._routes.push(n)}},{key:"_toReg",value:function(e){return e.params=[],e.reg="*"===e.path?/[\w\W]*/i:(0,a.default)(e.path,e.params,{end:!1}),e}},{key:"_getParams",value:function(){for(var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:[],t=arguments[1],n={},r=0;r<e.length;r++)n[e[r].name]=t[r+1];return n}}]),e}();t.default=s},function(e,t){function n(e,t){for(var n,r=[],o=0,u=0,s="",c=t&&t.delimiter||p,l=t&&t.delimiters||d,f=!1;null!==(n=y.exec(e));){var h=n[0],v=n[1],_=n.index;if(s+=e.slice(u,_),u=_+h.length,v)s+=v[1],f=!0;else{var m="",b=e[u],g=n[2],w=n[3],k=n[4],x=n[5];if(!f&&s.length){var E=s.length-1;l.indexOf(s[E])>-1&&(m=s[E],s=s.slice(0,E))}s&&(r.push(s),s="",f=!1);var O=""!==m&&void 0!==b&&b!==m,j="+"===x||"*"===x,P="?"===x||"*"===x,C=m||c,M=w||k;r.push({name:g||o++,prefix:m,delimiter:C,optional:P,repeat:j,partial:O,pattern:M?a(M):"[^"+i(C)+"]+?"})}}return(s||u<e.length)&&r.push(s+e.substr(u)),r}function r(e,t){return o(n(e,t))}function o(e){for(var t=new Array(e.length),n=0;n<e.length;n++)"object"==typeof e[n]&&(t[n]=new RegExp("^(?:"+e[n].pattern+")$"));return function(n,r){for(var o="",i=r&&r.encode||encodeURIComponent,a=0;a<e.length;a++){var u=e[a];if("string"!=typeof u){var s,c=n?n[u.name]:void 0;if(Array.isArray(c)){if(!u.repeat)throw new TypeError('Expected "'+u.name+'" to not repeat, but got array');if(0===c.length){if(u.optional)continue;throw new TypeError('Expected "'+u.name+'" to not be empty')}for(var l=0;l<c.length;l++){if(s=i(c[l]),!t[a].test(s))throw new TypeError('Expected all "'+u.name+'" to match "'+u.pattern+'"');o+=(0===l?u.prefix:u.delimiter)+s}}else if("string"!=typeof c&&"number"!=typeof c&&"boolean"!=typeof c){if(!u.optional)throw new TypeError('Expected "'+u.name+'" to be '+(u.repeat?"an array":"a string"));u.partial&&(o+=u.prefix)}else{if(s=i(String(c)),!t[a].test(s))throw new TypeError('Expected "'+u.name+'" to match "'+u.pattern+'", but got "'+s+'"');o+=u.prefix+s}}else o+=u}return o}}function i(e){return e.replace(/([.+*?=^!:${}()[\]|\/\\])/g,"\\$1")}function a(e){return e.replace(/([=!:$\/()])/g,"\\$1")}function u(e){return e&&e.sensitive?"":"i"}function s(e,t){if(!t)return e;var n=e.source.match(/\((?!\?)/g);if(n)for(var r=0;r<n.length;r++)t.push({name:r,prefix:null,delimiter:null,optional:!1,repeat:!1,partial:!1,pattern:null});return e}function c(e,t,n){for(var r=[],o=0;o<e.length;o++)r.push(h(e[o],t,n).source);return new RegExp("(?:"+r.join("|")+")",u(n))}function l(e,t,r){return f(n(e,r),t,r)}function f(e,t,n){n=n||{};for(var r=n.strict,o=!1!==n.end,a=i(n.delimiter||p),s=n.delimiters||d,c=[].concat(n.endsWith||[]).map(i).concat("$").join("|"),l="",f=!1,h=0;h<e.length;h++){var y=e[h];if("string"==typeof y)l+=i(y),f=h===e.length-1&&s.indexOf(y[y.length-1])>-1;else{var v=i(y.prefix),_=y.repeat?"(?:"+y.pattern+")(?:"+v+"(?:"+y.pattern+"))*":y.pattern;t&&t.push(y),y.optional?y.partial?l+=v+"("+_+")?":l+="(?:"+v+"("+_+"))?":l+=v+"("+_+")"}}return o?(r||(l+="(?:"+a+")?"),l+="$"===c?"$":"(?="+c+")"):(r||(l+="(?:"+a+"(?="+c+"))?"),f||(l+="(?="+a+"|"+c+")")),new RegExp("^"+l,u(n))}function h(e,t,n){return e instanceof RegExp?s(e,t):Array.isArray(e)?c(e,t,n):l(e,t,n)}e.exports=h,e.exports.parse=n,e.exports.compile=r,e.exports.tokensToFunction=o,e.exports.tokensToRegExp=f;var p="/",d="./",y=new RegExp(["(\\\\.)","(?:\\:(\\w+)(?:\\(((?:\\\\.|[^\\\\()])+)\\))?|\\(((?:\\\\.|[^\\\\()])+)\\))([+*?])?"].join("|"),"g")},function(e,t,n){"use strict";function r(e){var t={};return(e=e.trim().replace(/^(\?|#|&)/,""))?(e.split("&").forEach(function(e){var n=e.split("="),r=o(n,2),i=r[0],a=r[1],u=[decodeURIComponent(i),a?decodeURIComponent(a):null],s=u[0],c=u[1];t[s]=c}),t):null}Object.defineProperty(t,"__esModule",{value:!0});var o=function(){function e(e,t){var n=[],r=!0,o=!1,i=void 0;try{for(var a,u=e[Symbol.iterator]();!(r=(a=u.next()).done)&&(n.push(a.value),!t||n.length!==t);r=!0);}catch(e){o=!0,i=e}finally{try{!r&&u.return&&u.return()}finally{if(o)throw i}}return n}return function(t,n){if(Array.isArray(t))return t;if(Symbol.iterator in Object(t))return e(t,n);throw new TypeError("Invalid attempt to destructure non-iterable instance")}}();t.parseQuery=r},function(e,t,n){"use strict";function r(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function o(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function i(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}Object.defineProperty(t,"__esModule",{value:!0});var a=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),u=n(0),s=function(e){return e&&e.__esModule?e:{default:e}}(u),c=function(e){function t(e){r(this,t);var n=o(this,(t.__proto__||Object.getPrototypeOf(t)).call(this,e));return n._init(),window.addEventListener("load",n._listen),window.addEventListener("popstate",n._listen),n}return i(t,e),a(t,[{key:"_init",value:function(){var e=this;this._listen=function(t){var n=""+location.pathname+location.search,r=e.matcher.match(n);e._matchedCount=r.length,e._fireHandlers(r,t.state)}}},{key:"_routeTo",value:function(e,t){var n=this.matcher.match(e);this._matchedCount=n.length,this._fireHandlers(n,t)}},{key:"go",value:function(e,t){history.pushState(t,"",e),this._routeTo(e,t)}},{key:"redirect",value:function(e,t){history.replaceState(t,"",e),this._routeTo(e,t)}},{key:"back",value:function(){history.go(-1)}},{key:"stop",value:function(){window.removeEventListener("load",this._listen),window.removeEventListener("popstate",this._listen)}}]),t}(s.default);t.default=c},function(e,t,n){"use strict";function r(e,t){t&&i.setItem(""+a+e,JSON.stringify(t))}function o(e){try{var t=i.getItem(""+a+e);return t?JSON.parse(t):null}catch(e){throw new Error("parse body err")}}Object.defineProperty(t,"__esModule",{value:!0}),t.setCache=r,t.getCache=o;var i=sessionStorage,a="smer"},function(e,t,n){"use strict";function r(e,t,n){Object.defineProperty(e,t,{writable:!1,enumerable:!0,value:n})}Object.defineProperty(t,"__esModule",{value:!0}),t.def=r},function(e,t,n){"use strict";function r(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function o(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function i(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}Object.defineProperty(t,"__esModule",{value:!0});var a=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),u=n(0),s=function(e){return e&&e.__esModule?e:{default:e}}(u),c=function(e){function t(e){r(this,t);var n=o(this,(t.__proto__||Object.getPrototypeOf(t)).call(this,e));return n._cache={},n._init(),window.addEventListener("load",n._listen),window.addEventListener("hashchange",n._listen),n}return i(t,e),a(t,[{key:"_getHash",value:function(){return location.hash.slice(1)}},{key:"_init",value:function(){var e=this;this._listen=function(t){var n=e._getHash(),r=e.matcher.match(n);e._matchedCount=r.length,e._fireHandlers(r,e._cache[n])}}},{key:"go",value:function(e,t){this._cache[e]=t,location.hash=""+e}},{key:"redirect",value:function(e,t){var n=location.href,r=n.indexOf("#");e=r>0?n.slice(0,r)+"#"+e:n.slice(0,0)+"#"+e,this._cache[e]=t,location.replace(e)}},{key:"back",value:function(){history.go(-1)}},{key:"stop",value:function(){window.removeEventListener("load",this._listen),window.removeEventListener("hashchange",this._listen)}}]),t}(s.default);t.default=c}])});

/***/ })
/******/ ]);