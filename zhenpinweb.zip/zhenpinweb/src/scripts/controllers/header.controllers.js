const headerTpl = require('../views/header.html')
const userModel = require('../models/user')
var wsCache = new WebStorageCache();

const userStatus = {
    async render(req, res, next,router) {
        this.renderTpl({
            greeting: '',
            isSignin: false
        })
        this.isSignin(router)
        this.bindEvent()
        userStatus.bindSignOut(router)

    },
    bindEvent() {

        $('#user-submit-in').on('click', async(e) => {
            e.stopPropagation()
            e.preventDefault()
            let {adminname, password} = {
                adminname: $('#username').val(),
                password: $('#password').val()
            }
            let result = await userModel.sign({adminname, password}, 'login')
            if (result.ret) {
                // 将token保存到localstorage里
                // wsCache.set('token', result.data.token)
                wsCache.set('adminname', {adminname,password})
                this.renderTpl({
                    greeting: '你好管理员',
                    isSignin: true
                })
            }else{
                alert("用户名密码错误！")
            }
            $('#username').val('')
            $('#password').val('')
            userStatus.bindSignOut()
        })


    },
    bindSignOut(router){

        $('#user-signout').on('click', () => {
            wsCache.delete('adminname')
            this.renderTpl({
                greeting: '',
                isSignin: false
            })
            router.go('')

            userStatus.bindEvent()
            alert('已退出')
        })

    },

    async  isSignin(router){
        var storage = window.localStorage;
        if(storage.adminname){
            console.log('adminname',)
            this.renderTpl({
                greeting: '你好管理员',
                isSignin: true
            })
        } else {
            // router.go('/')
            this.renderTpl({
                greeting: '',
                isSignin: false
            })
            // alert('请先登录！')
            // return 0
        }
    },

    // async isSignin() {
    //     let token = wsCache.get('token')
    //     let result = await userModel.isSignin(token)
    //     if (result.ret) {
    //         this.renderTpl({
    //             greeting: '你好管理员',
    //             isSignin: true
    //         })
    //     } else {
    //         this.renderTpl({
    //             greeting: '',
    //             isSignin: false
    //         })
    //     }
    // },

    renderTpl({greeting, isSignin}) {
        let html = template.render(headerTpl, {
            greeting,
            isSignin
        })
        $('.main-header').remove()
        $('.wrapper').prepend(html)
        // this.bindEvent()
    }
}
module.exports = userStatus
