const sign = (data, url) => {
  console.log(data)
  return $.ajax({
    url: '/ssh1fs/api/admin/' + url,
    contentType: "application/json",
    type: 'post',
    data: JSON.stringify(data),
    success: (result) => {
      return result
    }
  })
}

const isSignin = (token) => {
  return $.ajax({
    url: '/api/systemapi/users/signin',
    type: 'post',
    headers: {
      //注意token的格式
      'X-Access-Token': token
    },
    success(result) {
      return result
    }
  })
}

module.exports = {
  sign,
  isSignin
}
